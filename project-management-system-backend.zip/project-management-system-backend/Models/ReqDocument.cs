﻿namespace project_management_system_backend.Models
{
    public class ReqDocument:BaseModel
    {
        public int ID { get; set; }
        public string Attachment { get; set; }
    }
}
