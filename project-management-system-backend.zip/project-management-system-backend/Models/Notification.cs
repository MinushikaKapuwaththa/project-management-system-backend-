﻿namespace project_management_system_backend.Models
{
    public class Notification:BaseModel
    {
        public int Id { get; set; }
        public string Message { get; set; }
    }
}
