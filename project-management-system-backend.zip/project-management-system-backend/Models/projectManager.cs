﻿namespace project_management_system_backend.Models
{
    public class projectManager:BaseModel
    {
        public int Id { get; set; }

    }
}
