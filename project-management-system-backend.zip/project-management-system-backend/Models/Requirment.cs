﻿namespace project_management_system_backend.Models
{
    public class Requirment:BaseModel
    {
        public int Id { get; set; }
        public string Distripation { get; set; }
        public ICollection<ReqirmentReqDoucment> ReqirmentReqs { get; set; }

    }
}
